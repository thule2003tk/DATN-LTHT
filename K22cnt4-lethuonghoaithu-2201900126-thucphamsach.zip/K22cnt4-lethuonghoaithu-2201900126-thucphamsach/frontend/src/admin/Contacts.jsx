function AdminContacts() {
  return (
    <div>
      <h2 className="text-success mb-4">Quản lý liên hệ</h2>
      <p>Trang này đang được phát triển...</p>
    </div>
  );
}

export default AdminContacts;