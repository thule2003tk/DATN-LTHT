function AdminSuppliers() {
  return (
    <div>
      <h2 className="text-success mb-4">Quản lý nhà cung cấp</h2>
      <p>Trang này đang được phát triển...</p>
    </div>
  );
}

export default AdminSuppliers;