function AdminPromotions() {
  return (
    <div>
      <h2 className="text-success mb-4">Quản lý khuyến mãi</h2>
      <p>Trang này đang được phát triển...</p>
    </div>
  );
}

export default AdminPromotions;